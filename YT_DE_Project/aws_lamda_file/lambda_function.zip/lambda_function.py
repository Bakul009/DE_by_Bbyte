import boto3
import requests
import json
from datetime import datetime
import os

# Your S3 bucket name
S3_BUCKET = "my-api-data-lambda"  # Replace with your bucket name

# YouTube API key
YOUTUBE_API_KEY = "AIzaSyCae-dMwc-91aD4ABQabW3NnQrhezCGPtY"  # Replace with your key

# YouTube API endpoint: get trending videos
API_URL = f"https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&chart=mostPopular&regionCode=IN&maxResults=50&key={YOUTUBE_API_KEY}"

s3 = boto3.client("s3")

def lambda_handler(event, context):
    # Step 1: Fetch trending video data
    response = requests.get(API_URL)
    if response.status_code != 200:
        return {"statusCode": 500, "body": "YouTube API request failed"}
    
    data = response.json()

    # Step 2: Prepare S3 folder & filename
    now = datetime.now()
    folder_path = f"{now.year}/{now.month:02d}/{now.day:02d}"
    filename = f"youtube_trending_{now.strftime('%H%M%S')}.json"
    s3_key = f"{folder_path}/{filename}"

    # Step 3: Upload data to S3
    s3.put_object(
        Bucket=S3_BUCKET,
        Key=s3_key,
        Body=json.dumps(data)
    )

    return {
        "statusCode": 200,
        "body": f"Uploaded YouTube trending data to S3 at {s3_key}"
    }
